# multa.py — o que a locadora cobra no balcão.

MULTA_POR_DIA = 5.00


def multa(dias_atraso, cliente_fiel=False):
    """Multa pela devolução atrasada, em reais. Cliente fiel paga metade."""
    if dias_atraso > 3:
        valor = dias_atraso * MULTA_POR_DIA
        if cliente_fiel:
            valor = valor / 2
        return valor
    return 0.0


def valor_do_aluguel(diaria, dias):
    """Quanto o cliente paga ao retirar o jogo."""
    if dias <= 0:
        raise ValueError("o aluguel precisa ser de pelo menos 1 dia")
    return diaria * dias
