# test_relatorio.py — um teste por classe de equivalência.

from relatorio import Aluguel, RelatorioDoMes, total_do_cliente


# ---------- RelatorioDoMes: blocos 1 a 3 ----------

def test_entende_alugueis_em_ordem_crescente():
    alugueis = [
        Aluguel("Carla", "Mario Kart", 25.0),
        Aluguel("Ana", "FIFA 25", 30.0),
        Aluguel("Bruno", "Zelda", 40.0),
    ]

    relatorio = RelatorioDoMes()
    relatorio.avaliar(alugueis)

    assert relatorio.maior == 40.0
    assert relatorio.menor == 25.0


def test_entende_alugueis_em_ordem_decrescente():
    alugueis = [
        Aluguel("Bruno", "Zelda", 40.0),
        Aluguel("Ana", "FIFA 25", 30.0),
        Aluguel("Carla", "Mario Kart", 25.0),
    ]

    relatorio = RelatorioDoMes()
    relatorio.avaliar(alugueis)

    assert relatorio.maior == 40.0
    assert relatorio.menor == 25.0


def test_entende_alugueis_fora_de_ordem():
    alugueis = [
        Aluguel("Ana", "FIFA 25", 30.0),
        Aluguel("Bruno", "Zelda", 40.0),
        Aluguel("Carla", "Mario Kart", 25.0),
    ]

    relatorio = RelatorioDoMes()
    relatorio.avaliar(alugueis)

    assert relatorio.maior == 40.0
    assert relatorio.menor == 25.0


def test_um_aluguel_so_e_o_maior_e_o_menor():
    alugueis = [Aluguel("Ana", "FIFA 25", 30.0)]

    relatorio = RelatorioDoMes()
    relatorio.avaliar(alugueis)

    assert relatorio.maior == 30.0
    assert relatorio.menor == 30.0


# ---------- total_do_cliente: a prática do bloco 4 ----------

ALUGUEIS_DO_MES = [
    Aluguel("Ana", "FIFA 25", 30.0),
    Aluguel("Bruno", "Zelda", 40.0),
    Aluguel("Ana", "Mario Kart", 25.0),
    Aluguel("Ana", "Zelda", 40.0),
]


def test_cliente_sem_aluguel_gastou_zero():
    assert total_do_cliente(ALUGUEIS_DO_MES, "Carla") == 0.0


def test_cliente_com_um_aluguel_gastou_o_valor_dele():
    assert total_do_cliente(ALUGUEIS_DO_MES, "Bruno") == 40.0


def test_cliente_com_varios_alugueis_soma_todos():
    assert total_do_cliente(ALUGUEIS_DO_MES, "Ana") == 95.0


def test_lista_vazia_da_zero():
    assert total_do_cliente([], "Ana") == 0.0
