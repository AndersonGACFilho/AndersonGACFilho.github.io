# test_multa.py — a fronteira da multa e o que tem de ser recusado.
import pytest

from multa import multa, valor_do_aluguel


# ---------- multa: a fronteira ----------

def test_dois_dias_de_atraso_nao_tem_multa():
    assert multa(2) == 0.0


def test_no_terceiro_dia_ja_cobra():
    assert multa(3) == 15.0


def test_quatro_dias_cobra_todos_os_dias():
    assert multa(4) == 20.0


def test_devolucao_no_prazo_nao_tem_multa():
    assert multa(0) == 0.0


# ---------- valor_do_aluguel: o caso que tem de ser recusado ----------

def test_aluguel_de_tres_dias():
    assert valor_do_aluguel(8.0, 3) == 24.0


def test_aluguel_de_zero_dias_e_recusado():
    with pytest.raises(ValueError):
        valor_do_aluguel(8.0, 0)


def test_aluguel_de_dias_negativos_e_recusado():
    with pytest.raises(ValueError):
        valor_do_aluguel(8.0, -2)
