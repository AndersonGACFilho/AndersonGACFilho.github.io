# dados.py — o acesso ao banco: o CRUD de jogo, e só ele.
#
# É o CRUD do notebook da UC2, já com a conexão por parâmetro (UC3, Aula 05)
# e com os dois defeitos que os testes de integração acharam corrigidos.
# Cada função devolve o resultado, e não imprime nada: quem decide o que
# mostrar à pessoa é a janela.

from decimal import Decimal

import psycopg2 as pg


class Jogo:
    def __init__(self, titulo, genero, ano_lancamento, preco_diaria, id_jogo=None):
        self.id_jogo = id_jogo
        self.titulo = titulo
        self.genero = genero
        self.ano_lancamento = ano_lancamento
        self.preco_diaria = preco_diaria

    def __repr__(self):
        return f"Jogo( {self.id_jogo} - {self.titulo} )"


def _linha_para_jogo(linha):
    return Jogo(linha[1], linha[2], linha[3], linha[4], linha[0])


def criar_jogo(conexao, titulo, genero, ano_lancamento, preco_diaria):
    """Grava o jogo e devolve-o com o id. Se o banco recusar, levanta o erro."""
    cursor = conexao.cursor()
    try:
        cursor.execute(
            "INSERT INTO jogo (titulo, genero, ano_lancamento, preco_diaria) "
            "VALUES (%s, %s, %s, %s) RETURNING id_jogo",
            (titulo, genero, ano_lancamento, preco_diaria),
        )
        id_jogo = cursor.fetchone()[0]
        conexao.commit()
    except pg.DatabaseError:
        # desfaz e devolve o erro para cima: a janela é que sabe avisar a
        # pessoa; aqui embaixo, um print sumiria no terminal
        conexao.rollback()
        raise
    return Jogo(titulo, genero, ano_lancamento, Decimal(str(preco_diaria)), id_jogo)


def listar_jogos(conexao):
    cursor = conexao.cursor()
    cursor.execute(
        "SELECT id_jogo, titulo, genero, ano_lancamento, preco_diaria "
        "FROM jogo ORDER BY titulo"
    )
    return [_linha_para_jogo(linha) for linha in cursor.fetchall()]


def buscar_jogo(conexao, id_jogo):
    cursor = conexao.cursor()
    cursor.execute(
        "SELECT id_jogo, titulo, genero, ano_lancamento, preco_diaria "
        "FROM jogo WHERE id_jogo = %s",
        (id_jogo,),
    )
    linha = cursor.fetchone()
    return _linha_para_jogo(linha) if linha else None


def deletar_jogo(conexao, id_jogo):
    """Apaga o jogo e o vínculo dele com as plataformas. True se apagou."""
    cursor = conexao.cursor()
    try:
        cursor.execute("DELETE FROM jogos_plataforma WHERE id_jogo = %s", (id_jogo,))
        cursor.execute("DELETE FROM jogo WHERE id_jogo = %s", (id_jogo,))
        apagadas = cursor.rowcount
        conexao.commit()
    except pg.DatabaseError:
        conexao.rollback()
        raise
    return apagadas > 0
