# regras.py — as regras do negócio da locadora.
#
# Nenhuma linha aqui sabe que existe banco ou janela. Por isso estas funções
# se testam com o pytest puro, em milissegundos (Aulas 01 a 03 da UC3).

MULTA_POR_DIA = 5.00


def multa(dias_atraso):
    """A partir do 3º dia de atraso, R$ 5,00 por dia — todos os dias."""
    if dias_atraso >= 3:
        return dias_atraso * MULTA_POR_DIA
    return 0.0


def valor_do_aluguel(diaria, dias):
    """A diária vezes os dias. Aluguel de zero dias, ou menos, não existe."""
    if dias <= 0:
        raise ValueError("o aluguel precisa ser de pelo menos 1 dia")
    return diaria * dias


def validar_jogo(titulo, ano, preco_diaria):
    """Confere o que a pessoa digitou antes de ir ao banco.

    Recebe o texto dos campos, como veio da tela, e devolve a lista de
    problemas em português — vazia quando está tudo certo. A janela mostra a
    lista; o banco nem é chamado.
    """
    problemas = []
    if not titulo.strip():
        problemas.append("O título não pode ficar em branco.")
    if ano.strip():
        if not ano.strip().isdigit():
            problemas.append("O ano tem de ser um número, como 2017.")
        elif int(ano) <= 1970:
            # a mesma regra do CHECK da tabela jogo (UC2, Aula 11): avisar
            # aqui é avisar em português, antes do erro do banco
            problemas.append("O ano tem de ser depois de 1970.")
    try:
        preco = float(preco_diaria.replace(",", "."))
    except ValueError:
        problemas.append("O preço da diária tem de ser um número, como 8,50.")
    else:
        if preco < 0:
            problemas.append("O preço da diária não pode ser negativo.")
    return problemas
