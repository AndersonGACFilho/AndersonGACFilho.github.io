# test_regras.py — a camada de regras, sem banco e sem janela.

import pytest

from locadora.regras import multa, validar_jogo, valor_do_aluguel


def test_dois_dias_de_atraso_nao_tem_multa():
    assert multa(2) == 0.0


def test_no_terceiro_dia_ja_cobra():
    assert multa(3) == 15.0


def test_aluguel_de_zero_dias_e_recusado():
    with pytest.raises(ValueError):
        valor_do_aluguel(8.0, 0)


def test_jogo_completo_nao_tem_problema():
    assert validar_jogo("Zelda", "2017", "8,50") == []


def test_titulo_em_branco_e_recusado():
    assert validar_jogo("   ", "2017", "8,50") == ["O título não pode ficar em branco."]


def test_ano_nao_numerico_e_recusado():
    assert validar_jogo("Zelda", "dois mil", "8,50") == ["O ano tem de ser um número, como 2017."]


def test_ano_antes_de_1971_e_recusado():
    assert validar_jogo("Pong", "1970", "1") == ["O ano tem de ser depois de 1970."]


def test_ano_pode_ficar_em_branco():
    assert validar_jogo("Zelda", "", "8") == []


def test_preco_negativo_e_recusado():
    assert validar_jogo("Zelda", "2017", "-1") == ["O preço da diária não pode ser negativo."]


def test_preco_com_letra_e_recusado():
    assert validar_jogo("Zelda", "2017", "oito") == [
        "O preço da diária tem de ser um número, como 8,50."
    ]
