-- criar_tabelas.sql — as tabelas que este módulo usa.
--
-- Rode no pgAdmin, no Query Tool, uma vez no banco "locadora" e outra no
-- "locadora_teste". Pode rodar de novo sem estragar nada: só cria o que
-- ainda não existe (PADRAO-SQL da UC2).

CREATE TABLE IF NOT EXISTS plataforma (
    id_plataforma  SERIAL       PRIMARY KEY,
    nome           VARCHAR(50)  NOT NULL UNIQUE,
    fabricante     VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS jogo (
    id_jogo         SERIAL         PRIMARY KEY,
    titulo          VARCHAR(150)   NOT NULL UNIQUE,
    genero          VARCHAR(40),
    ano_lancamento  INTEGER        CHECK (ano_lancamento > 1970),
    preco_diaria    NUMERIC(10,2)  CHECK (preco_diaria >= 0)
);

CREATE TABLE IF NOT EXISTS jogos_plataforma (
    id_jogo        INTEGER  NOT NULL REFERENCES jogo(id_jogo),
    id_plataforma  INTEGER  NOT NULL REFERENCES plataforma(id_plataforma),
    PRIMARY KEY (id_jogo, id_plataforma)
);
