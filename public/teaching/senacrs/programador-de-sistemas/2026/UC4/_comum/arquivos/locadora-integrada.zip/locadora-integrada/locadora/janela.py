# janela.py — a interface: o que a pessoa vê e clica.
#
# Esta camada não tem regra nem SQL. Ela pede à regras.py para conferir o que
# foi digitado e à dados.py para gravar; o que sobra aqui é só tela. É por isso
# que ela quase não tem teste automático — e não precisa: o que pode dar errado
# de verdade mora nas outras duas camadas, que têm.

import tkinter as tk
from tkinter import font, messagebox, ttk

import psycopg2 as pg

from locadora import dados, regras


def _em_reais(valor):
    """8.5 -> "R$ 8,50": o balcão lê vírgula, não ponto."""
    return f"R$ {valor:.2f}".replace(".", ",")


class JanelaDeJogos(tk.Tk):
    def __init__(self, conexao):
        super().__init__()
        self.conexao = conexao
        self.title("Locadora — jogos")
        # letra maior que o padrão do Tkinter (9 ou 10): a janela vai ser
        # usada no balcão e mostrada no projetor
        for nome in ("TkDefaultFont", "TkTextFont", "TkHeadingFont"):
            font.nametofont(nome).configure(size=12)

        self._montar_formulario()
        self._montar_tabela()
        self.atualizar_tabela()

    # ---------- montagem da tela ----------

    def _montar_formulario(self):
        quadro = ttk.LabelFrame(self, text="Cadastrar jogo", padding=12)
        quadro.grid(row=0, column=0, sticky="ew", padx=12, pady=12)
        self.campos = {}
        for linha, (chave, rotulo) in enumerate(
            [("titulo", "Título"), ("genero", "Gênero"), ("ano", "Ano"), ("preco", "Diária (R$)")]
        ):
            ttk.Label(quadro, text=rotulo).grid(row=linha, column=0, sticky="w", pady=3, padx=(0, 10))
            campo = ttk.Entry(quadro, width=32)
            campo.grid(row=linha, column=1, sticky="ew", pady=3)
            self.campos[chave] = campo
        ttk.Button(quadro, text="Cadastrar", command=self.cadastrar).grid(
            row=4, column=1, sticky="e", pady=(8, 0)
        )
        # Enter em qualquer campo cadastra: quem digita não precisa do mouse
        self.bind("<Return>", lambda _evento: self.cadastrar())

    def _montar_tabela(self):
        colunas = ("titulo", "genero", "ano", "preco")
        self.tabela = ttk.Treeview(self, columns=colunas, show="headings", height=10)
        for coluna, titulo in zip(colunas, ("Título", "Gênero", "Ano", "Diária")):
            self.tabela.heading(coluna, text=titulo)
        self.tabela.grid(row=1, column=0, sticky="nsew", padx=12)
        ttk.Button(self, text="Apagar o selecionado", command=self.apagar).grid(
            row=2, column=0, sticky="e", padx=12, pady=12
        )
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

    # ---------- o que os botões fazem ----------

    def atualizar_tabela(self):
        self.tabela.delete(*self.tabela.get_children())
        for jogo in dados.listar_jogos(self.conexao):
            self.tabela.insert(
                "", "end", iid=str(jogo.id_jogo),
                values=(jogo.titulo, jogo.genero or "", jogo.ano_lancamento or "", _em_reais(jogo.preco_diaria)),
            )

    def cadastrar(self):
        texto = {chave: campo.get() for chave, campo in self.campos.items()}
        problemas = regras.validar_jogo(texto["titulo"], texto["ano"], texto["preco"])
        if problemas:
            messagebox.showwarning("Confira os dados", "\n".join(problemas), parent=self)
            return
        try:
            dados.criar_jogo(
                self.conexao,
                texto["titulo"].strip(),
                texto["genero"].strip() or None,
                int(texto["ano"]) if texto["ano"].strip() else None,
                texto["preco"].replace(",", "."),
            )
        except pg.errors.UniqueViolation:
            messagebox.showerror("Jogo repetido", "Já existe um jogo com esse título.", parent=self)
            return
        except pg.DatabaseError as erro:
            messagebox.showerror("O banco recusou", str(erro), parent=self)
            return
        for campo in self.campos.values():
            campo.delete(0, "end")
        self.atualizar_tabela()

    def apagar(self):
        selecionado = self.tabela.selection()
        if not selecionado:
            messagebox.showinfo("Apagar", "Escolha um jogo na tabela primeiro.", parent=self)
            return
        titulo = self.tabela.item(selecionado[0], "values")[0]
        if not messagebox.askyesno("Apagar", f"Apagar {titulo}?", parent=self):
            return
        dados.deletar_jogo(self.conexao, int(selecionado[0]))
        self.atualizar_tabela()
