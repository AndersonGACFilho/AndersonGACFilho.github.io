# conftest.py — a conexão com o banco de TESTE, limpa antes de cada teste.
#
# É a fixture da UC3, Aula 05. A senha vem do .env, pela mesma função que a
# janela usa — só muda o banco: PG_BANCO_DE_TESTE, nunca o de verdade.

import pytest

from locadora.conexao import conectar


@pytest.fixture
def conexao():
    conexao = conectar("PG_BANCO_DE_TESTE")
    cursor = conexao.cursor()
    cursor.execute("TRUNCATE jogo, plataforma RESTART IDENTITY CASCADE")
    conexao.commit()
    yield conexao
    conexao.close()
