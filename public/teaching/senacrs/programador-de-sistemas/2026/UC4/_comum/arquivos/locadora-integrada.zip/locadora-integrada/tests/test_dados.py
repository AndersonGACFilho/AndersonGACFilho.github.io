# test_dados.py — a camada de dados, no banco de teste de verdade.

from decimal import Decimal

import psycopg2 as pg
import pytest

from locadora.dados import buscar_jogo, criar_jogo, deletar_jogo, listar_jogos


def test_cria_e_busca(conexao):
    criado = criar_jogo(conexao, "Zelda", "Aventura", 2017, "8.00")

    achado = buscar_jogo(conexao, criado.id_jogo)

    assert achado.titulo == "Zelda"
    assert achado.preco_diaria == Decimal("8.00")


def test_lista_em_ordem_de_titulo(conexao):
    criar_jogo(conexao, "Zelda", "Aventura", 2017, "8.00")
    criar_jogo(conexao, "FIFA 25", "Esporte", 2024, "9.00")

    assert [j.titulo for j in listar_jogos(conexao)] == ["FIFA 25", "Zelda"]


def test_titulo_repetido_e_recusado_pelo_banco(conexao):
    criar_jogo(conexao, "Zelda", "Aventura", 2017, "8.00")

    with pytest.raises(pg.errors.UniqueViolation):
        criar_jogo(conexao, "Zelda", "RPG", 2020, "5.00")


def test_apaga_jogo_que_tem_plataforma(conexao):
    criado = criar_jogo(conexao, "Zelda", "Aventura", 2017, "8.00")
    cursor = conexao.cursor()
    cursor.execute("INSERT INTO plataforma (nome) VALUES ('Switch') RETURNING id_plataforma")
    cursor.execute(
        "INSERT INTO jogos_plataforma (id_jogo, id_plataforma) VALUES (%s, %s)",
        (criado.id_jogo, cursor.fetchone()[0]),
    )
    conexao.commit()

    assert deletar_jogo(conexao, criado.id_jogo) is True
    assert buscar_jogo(conexao, criado.id_jogo) is None
