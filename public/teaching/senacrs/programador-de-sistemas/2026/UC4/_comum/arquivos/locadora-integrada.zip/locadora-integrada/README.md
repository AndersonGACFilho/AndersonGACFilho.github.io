# Locadora — módulo de jogos

O cadastro de jogos da locadora, numa janela: listar, cadastrar e apagar. É o
exemplo da UC4 (Projeto Integrador) de como fica um projeto **organizado**: a
interface da UC1, o banco da UC2 e os testes da UC3, num repositório só.

## Como está organizado

```
main.py                  por onde o sistema começa
locadora/
    janela.py            interface — o que a pessoa vê e clica (Tkinter)
    regras.py            regras do negócio — o que pode e o que não pode
    dados.py             acesso ao banco — o SQL, e só ele
    conexao.py           abre a conexão a partir do .env
tests/
    test_regras.py       as regras, sem banco e sem janela
    test_dados.py        o acesso ao banco, no banco de teste
    conftest.py          a conexão com o banco de teste, limpa a cada teste
banco/criar_tabelas.sql  as tabelas
docs/RECUPERACAO.md      como recuperar o sistema se a máquina sumir
```

Cada camada só conversa com a de baixo: a janela chama `regras` e `dados`, e
nunca escreve SQL.

## Como rodar

1. Instale o Python 3 e o PostgreSQL (com o pgAdmin).
2. No pgAdmin, crie os bancos `locadora` e `locadora_teste`, e rode o
   `banco/criar_tabelas.sql` nos dois.
3. Copie o `.env.exemplo`, renomeie a cópia para `.env` e ponha a senha do
   seu PostgreSQL. O `.env` nunca vai para o repositório.
4. Instale as bibliotecas: num notebook aberto nesta pasta, uma célula com
   `%pip install -r requirements.txt`.
5. Abra o `main.py` no VS Code e clique no ▶.

## Como rodar os testes

No VS Code, painel **Testing** (o frasco) → ▶. Os testes de dados usam o banco
`locadora_teste`, que é apagado antes de cada teste — nunca aponte para o
`locadora`.
